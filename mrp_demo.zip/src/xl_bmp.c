#include "mrc_base.h"
#include "xl_bmp.h"

extern int gl_bitmapShowExTrans(uint16 *p,
                         int16 x,
                         int16 y,
                         int16 mw,
                         int16 w,
                         int16 h,
                         uint16 rop,
                         int16 sx,
                         int16 sy,
                         uint16 transcolor);
void* mr_malloc(int32 len){
  char *buf = NULL;
  buf = (char*)mrc_malloc(len-4);
  return buf-4;
}

//构建一个bmp 参数：内存数据，宽度，高度，透明色(0表示不透明)
BITMAP_565* bmp_create(uint16 *bitmap, int width, int height, int transcolor){
 BITMAP_565* bmp = mrc_malloc(sizeof(BITMAP_565));
 mrc_memset(bmp, 0, sizeof(BITMAP_565));
 bmp->bitmap = bitmap;
 bmp->width = width;
 bmp->height = height;
 bmp->color_bit = 16;
 bmp->mode = BM_COPY;
 if(transcolor!=0){
  bmp->mode = BM_TRANSPARENT;
  bmp->transcolor = transcolor;
 }
 return bmp;
}

//读取一个低位int类型数字
int get_int(char *buf,int ptr){
 int num = (buf[ptr]&0xff) | (buf[ptr+1]<<8) | (buf[ptr+2]<<16) | (buf[ptr+3]<<24);
 return num;
}

static int get_short(char *buf,int ptr){
 int num = (buf[ptr]&0xff) | (buf[ptr+1]<<8);
 return num;
}

//读取bmp
BITMAP_565* bmp_read(void *buf, int len){
 char *bufc = (char*)buf;
 int ptr=0;
 int w=0,h=0;
 int bit=16; //bmp位数
 int bmpstart=0; //bmp数据位置
 int iy=0;
 int i=0;
 uint16 *buf16 = NULL;
 char *buf24 = NULL;
 int tcolor = 0;
 int wsize;
 int iw;
 BITMAP_565* bmp = mrc_malloc(sizeof(BITMAP_565));
 mrc_memset(bmp,0,sizeof(BITMAP_565));
 bmp->color_bit = 16;
 bmp->mode = BM_COPY;
 bmp->buflen = len;
 //检测文件头
 if(bufc[0]=='B' && bufc[1]=='M'){
  ptr = 10;
  bmpstart = get_int(bufc,ptr);
  ptr = 18;
  w = get_int(bufc,ptr);
  ptr = 22;
  h = get_int(bufc,ptr);
  ptr = 28;
  bit = get_short(bufc,ptr);
  if(bit == 16){
   ptr = bmpstart;
   bmp->width = w;
   bmp->height = h;
   bmp->bitmap = (uint16*)mrc_malloc(w*h*2);
   bmp->buflen = w*h*2;
   //复制位图数据
   for( iy=0;iy<bmp->height;iy++){
    mrc_memcpy(bmp->bitmap+iy*bmp->width, bufc+ptr+(bmp->height-1-iy)*bmp->width*2, w*2);
   }
   
  }
  else if(bit == 24){
   ptr = bmpstart;
   bmp->width = w;
   bmp->height = h;
   //对齐字节
   wsize = w*3;
   if(wsize%4!=0) wsize = wsize - wsize%4 + 4;
   bmp->bitmap = (uint16*)mr_malloc(w*h*2);
   bmp->buflen = w*h*2;
   
   //32转16位
    buf16 = (unsigned short*)mrc_malloc(bmp->width*bmp->height*2);
    buf24 = (bufc+ptr);
   for(i=0;i<h;i++){
     for(iw=0;iw<w;iw++){
    //BGRA
     tcolor = (((buf24[i*wsize+iw*3]>>3)&0x1f) 
    | ((buf24[i*wsize+iw*3+1]<<3)&0x7e0) 
    | ((buf24[i*wsize+iw*3+2]<<8)&0xf800));
    buf16[i*w+iw] = (uint16)(tcolor&0xffff);
     }
   }
   //复制位图数据
    for(iy=0;iy<bmp->height;iy++){
     mrc_memcpy (bmp->bitmap + iy*bmp->width, buf16+(bmp->height-1-iy)*bmp->width,w*2);
   }
   mrc_free(buf16);
  }
 }
 else
 {
  return NULL;
 }
 return bmp;
}

BITMAP_565* bma_read(void *buf, int len){
 char *bufc = (char*)buf;
 int ptr=0;

 BITMAP_565* bmp = mrc_malloc(sizeof(BITMAP_565));
 mrc_memset(bmp,0,sizeof(BITMAP_565));
 
 bmp->mode = BM_COPY;
 bmp->buflen = len;
 if(bufc[0] == 'M' && bufc[1] == 'A' && bufc[2] == 'P' && bufc[3] == '5'){
   bmp->color_bit = 16;
   ptr = 4;
   bmp->width = get_int(bufc, ptr);
   ptr = 8;
   bmp->height = get_int(bufc, ptr);
   ptr = 12;
   bmp->transcolor = get_short(bufc, ptr);
   if(bmp->transcolor != 0){
    bmp->mode = BM_TRANSPARENT;
   }
   ptr = 14;
   mrc_memmove(bufc, bufc+ptr, bmp->width * bmp->height * 2);
   bmp->bitmap = (uint16*)bufc;
 }
 else if(bufc[0] == 'M' && bufc[1] == 'A' && bufc[2] == 'P' && bufc[3] == '8'){
   bmp->color_bit = 32;
    ptr = 4;
   bmp->width = get_int(bufc, ptr);
   ptr = 8;
   bmp->height = get_int(bufc, ptr);
   ptr = 12;
   bmp->transcolor = get_short(bufc, ptr);
   if(bmp->transcolor != 0){
    bmp->mode = BM_TRANSPARENT;
   }
   ptr = 14;
   mrc_memmove(bufc, bufc+ptr, bmp->width * bmp->height * 4);
   bmp->bitmap = (uint16*)bufc;
 }
 else
 {
  mrc_free(bmp);
  return NULL;
 }
 return bmp;
}

//设置透明色 argb
void bmp_settranscolor(BITMAP_565* bmp, int color){
 bmp->transcolor = ((color>>8)&0xf800) | ((color>>5)&0x07e0) | ((color>>3)&0x1f);
 if(color != 0){
  bmp->mode = BM_TRANSPARENT;
 }
 else{
  bmp->mode = BM_COPY;
 }
 
}
//显示bmp
void bmp_draw(BITMAP_565* bmp, int x,int y){
 gl_bitmapShowExTrans(bmp->bitmap, (int16)x,(int16)y, (uint16)bmp->width, (uint16)bmp->width,(uint16)bmp->height, (uint16)bmp->mode, 0,0,(uint16)bmp->transcolor);
}
//区域显示bmp
void bmp_drawflip(BITMAP_565* bmp, int x,int y,int w,int h,int tx,int ty){
 gl_bitmapShowExTrans(bmp->bitmap, (int16)x, (int16)y, (uint16)bmp->width, (uint16)w,(uint16)h, (uint16)bmp->mode, (int16)tx,(int16)ty,(uint16)bmp->transcolor);
}
//bmp释放
void bmp_free(BITMAP_565* bmp){
  if(bmp->memlen>0){
    mrc_free(bmp->memcache);
    bmp->memlen = 0;
  }
 mrc_freeFileData(bmp->bitmap, bmp->buflen);
 bmp->bitmap = NULL;
 mrc_free(bmp);
}