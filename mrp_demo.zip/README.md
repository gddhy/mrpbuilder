# 功能机游戏开发规范

本文档为功能机平台（冒泡平台）游戏开发人员提供编写规范和最佳实践指南。



---

## 一、基础开发约束

1. 不能使用线程，使用定时器模拟游戏主循环
2. 绘图结束后必须调用mrc_refreshScreen来更新屏幕区域，否则无法屏幕无法显示
3. mrc_init mrc_event mrc_pause mrc_resume mrc_exitApp是程序的入口函数，必须实现
4. mrc_extRecvAppEvent mrc_extRecvAppEventEx 是插件调用函数，保留它，否则编译不过

### 1.1 编译器和语言标准
- **编译器**：使用 `arm-none-eabi-gcc` 编译器
- **语言标准**：严格遵循 **C99 标准**，支持C99特性
- **变量声明**：所有变量必须在函数或代码块开头声明，不能在中间声明
  ```c
  /* 正确示例 */
  void foo(void) {
      int i;
      char* text;
      /* 变量全部在开头声明 */

      i = 0;
      text = "hello";
  }

  /* 错误示例 */
  void bar(void) {
      doSomething();
      int i = 0;  /* 错误：变量声明不在开头 */
  }
  ```

### 1.2 不支持的系统头文件

- 不能使用标准 C 库头文件（如 `string.h`、`stdlib.h`）
- 但相关函数已映射到 mrc 函数，可直接使用：
  ```c
  malloc   -> mrc_malloc
  free     -> mrc_free
  memcpy   -> mrc_memcpy
  memset   -> mrc_memset
  strcpy   -> mrc_strcpy
  strcmp   -> mrc_strcmp
  sprintf  -> mrc_sprintf
  atoi     -> mrc_atoi
  ```

### 1.3 可用头文件
```c
#include <mrc_base.h>       /* 基础API、按键定义、事件定义 */
#include "uc3_font.h"       /* 字体绘制 */
#include "mrc_graphics.h"   /* 图形绘制API */
#include "mpc.h"            /* 基础功能转换支持(比如初始化SCRW、SCRH，强烈建议添加)， */
```

### 1.4 线程与定时器
- **禁止使用线程**：功能机不支持多线程
- **游戏主循环**：使用定时器 `mrc_timerCreate/Start` 模拟游戏循环
  ```c
  /* 创建定时器实现30fps游戏循环 */
  timer_cd = mrc_timerCreate();
  mrc_timerStart(timer_cd, 33, 0, timer_run, 1);  /* 33ms = 30fps */
  ```

### 1.5 随机数

```
mrc_sand(mrc_getUptime()); //随机数种子初始化,mrc_getUptime为获取当前系统时间（毫秒）
int rr = mrc_rand(); //生成一个随机数
```

### 1.6 屏幕特性

功能机屏幕是一块内存区域，颜色值RGB565，通过uint16 *w_getScreenBuffer()获得屏幕缓冲区，通过mrc_getScreenInfo获得屏幕宽度和屏幕高度。

屏幕宽高一般为240x320

```
    mr_screeninfo screen;
    mrc_getScreenInfo(&screen);
    uint32 width = screen.width; //屏幕宽度
    uint32 height = screen.height; //屏幕高度
```

建议直接引用mpc.h中的SCRW, SCRH变量获取屏幕宽高

以下定义在mpc.h中

```
 int16 SCRW;  
 int16 SCRH;
```



### 1.7 程序开发模版(main.c)

```
#include <mrc_base.h>

#include "uc3_font.h"
#include "mpc.h"
#include "mrc_graphics.h"
#include "xl_debug.h"

int32 timer_cd;
extern void drawGame(void);
void timer_run(int32 id)
{
  
  drawGame();
  return;
}

void drawGame(void)
{
  char *text_exit = NULL;
  int width = 0;
  mrc_clearScreen(0, 0, 0);

  uc3_drawText("测试字体 风的影子，制作", 10, 10, 255, 255, 255, 0);
  
  uc3_drawTextInRect("多行文本绘制\n测试测试\n这是多行文本哈哈哈哈哈哈哈",0, -8,   10, 60, 120, 32,   200, 120, 250, 0);
  
  text_exit = "退出";
  width = uc3_getWidth(text_exit, 0);
  uc3_drawText(text_exit, SCRW - width, SCRH - 16, 255, 255, 255, 0);
  mrc_refreshScreen(0, 0, SCRW, SCRH);
}

int32 mrc_init(void)
{

  mrc_printf("mpc init");
  mpc_init(); //初始化基础功能转换

  mrc_printf("uc3 init");
  uc3_init(); //初始化uc3字体
  
  mrc_printf("getuptime");
  mrc_sand(mrc_getUptime()); //随机数种子初始化,mrc_getUptime为获取当前系统时间（毫秒）

  mrc_printf("draw....");
  drawGame();

  mrc_printf("创建定时器");
  timer_cd = mrc_timerCreate();
  mrc_timerStart(timer_cd, 33, 0, timer_run, 0);

  return 0;
}

int32 mrc_event(int32 code, int32 param0, int32 param1)
{
  if (code == MR_KEY_RELEASE)
  {
    if (param0 == MR_KEY_SOFTRIGHT)
    {
      mrc_exit();
    }
  }
  else if (code == MR_MOUSE_UP)
  {
    mrc_exit();
  }
  return 0;
}
int32 mrc_pause() { return 0; }
int32 mrc_resume() { return 0; }
int32 mrc_exitApp()
{
  int i = 0;
  mrc_timerStop(timer_cd);
  mrc_timerDelete(timer_cd);
  // 释放字体
  uc3_free();

  return 0;
}

int32 mrc_extRecvAppEvent(int32 app, int32 code, int32 param0, int32 param1)
{
  mrc_printf("mrc_extRecvAppEvent");
  return 0;
}
int32 mrc_extRecvAppEventEx(int32 code, int32 p0, int32 p1, int32 p2, int32 p3,
                            int32 p4, int32 p5)
{
  mrc_printf("mrc_extRecvAppEventEx");
  return 0;
}
```





---

## 二、窗口管理系统

### 2.1 窗口类型定义
使用枚举定义所有窗口类型，便于管理：
```c
/* 窗口类型枚举 */
enum {
    WINDOW_MENU = 0,    /* 主菜单窗口 */
    WINDOW_GAME = 1,    /* 游戏窗口 */
    WINDOW_HELP = 2,    /* 帮助窗口 */
    WINDOW_ABOUT = 3    /* 关于窗口 */
};

/* 全局当前窗口变量 */
int currentWindow;
```

### 2.2 窗口切换函数
实现统一的窗口切换函数，集中管理页面跳转逻辑：
```c
void switchWindow(int windex, int level) {
    if (windex == 1) {
        /* 从菜单进入其他窗口 */
        if (level == MENU_GAME) {
            currentWindow = WINDOW_GAME;
            initGame();
            drawGame();
        } else if (level == MENU_HELP) {
            currentWindow = WINDOW_HELP;
            drawHelp();
        }
    } else if (windex == 0) {
        /* 返回菜单 */
        currentWindow = WINDOW_MENU;
        pmenu_draw(&mainMenu);
    }
}
```

### 2.3 事件分发机制
在 `mrc_event` 中根据当前窗口分发事件：
```c
int32 mrc_event(int32 code, int32 param0, int32 param1) {
    if (currentWindow == WINDOW_MENU) {
        /* 菜单窗口事件 */
        pmenu_event(&mainMenu, code, param0, param1);
    } else if (currentWindow == WINDOW_GAME) {
        /* 游戏窗口事件 */
        gameEvent(code, param0, param1);
    } else if (currentWindow == WINDOW_HELP) {
        /* 帮助窗口事件 */
        helpEvent(code, param0, param1);
    }
    return 0;
}
```

### 2.4 游戏逻辑隔离
定时器回调中只在游戏窗口时执行游戏逻辑：
```c
void timer_run(int32 id) {
    /* 只在游戏窗口时更新游戏状态 */
    if (currentWindow == WINDOW_GAME) {
        updateGame();
        drawGame();
    }
}
```

---

## 三、软键提示规范

### 3.1 软键位置和作用

功能机通常有两个软键（左软键和右软键），位于屏幕下方实体按键区域：

| 软键 | 按键常量 | 位置 | 常用功能 |
|-----|---------|------|---------|
| 左软键 | `_SLEFT` | 屏幕左下 | **确认** / 选择 / 进入 |
| 右软键 | `_SRIGHT` | 屏幕右下 | **返回** / 取消 / 退出 |

### 3.2 屏幕提示显示规范

**必须在屏幕底部显示软键提示文字**，告知用户按键功能：

```
┌─────────────────────────────┐
│                             │
│     游戏内容区域            │
│                             │
│                             │
├─────────────────────────────┤
│ 确认              返回      │  ← 软键提示区域
└─────────────────────────────┘
  ↑                   ↑
 左软键              右软键
```

### 3.3 软键提示实现示例

#### 方法一：简洁文字（推荐）
```c
void drawSoftKeyHints(char* leftText, char* rightText) {
    int leftX, rightX, y;

    y = SCRH - 25;  /* 距离底部25像素 */

    /* 左软键提示（屏幕左下） */
    if (leftText != NULL) {
        leftX = 10;
        uc3_drawText(leftText, leftX, y, 0, 0, 0, 0);
    }

    /* 右软键提示（屏幕右下） */
    if (rightText != NULL) {
        rightX = SCRW - uc3_getWidth(rightText, 0) - 10;
        uc3_drawText(rightText, rightX, y, 0, 0, 0, 0);
    }
}

/* 使用示例 */
drawSoftKeyHints("确认", "返回");
```

#### 方法二：带背景高亮（可选）
```c
void drawSoftKeyHintsWithBg(char* leftText, char* rightText) {
    int leftX, rightX, y;
    int textW;

    y = SCRH - 30;

    /* 左软键 */
    if (leftText != NULL) {
        leftX = 10;
        textW = uc3_getWidth(leftText, 0);
        gl_drawRect(leftX - 5, y - 2, textW + 10, 20, 0xFFE0E0E0);
        uc3_drawText(leftText, leftX, y, 0, 0, 0, 0);
    }

    /* 右软键 */
    if (rightText != NULL) {
        textW = uc3_getWidth(rightText, 0);
        rightX = SCRW - textW - 10;
        gl_drawRect(rightX - 5, y - 2, textW + 10, 20, 0xFFE0E0E0);
        uc3_drawText(rightText, rightX, y, 0, 0, 0, 0);
    }
}
```

### 3.4 不同场景的软键配置

| 场景 | 左软键文字 | 右软键文字 | 说明 |
|-----|-----------|-----------|------|
| 主菜单 | "选择" / "确认" | "退出" | 左键进入选项，右键退出程序 |
| 游戏中 | NULL | "返回" | 只显示返回，游戏操作靠触屏 |
| 帮助页面 | "确认" | "返回" | 确认关闭帮助，返回菜单 |
| 设置页面 | "保存" | "取消" | 保存设置或取消 |
| 对话框 | "确定" | "取消" | 确认或取消操作 |

### 3.5 事件处理示例

```c
void gameEvent(int32 code, int32 param0, int32 param1) {
    if (code == KY_UP) {  /* 按键松开事件 */
        if (param0 == _SRIGHT) {
            /* 右软键：返回菜单 */
            switchWindow(0, 0);
        } else if (param0 == _SLEFT) {
            /* 左软键：暂停游戏 */
            gamePause();
        }
    }
}

void menuEvent(int32 code, int32 param0, int32 param1) {
    if (code == KY_UP) {
        if (param0 == _SLEFT) {
            /* 左软键：确认进入选中项 */
            enterMenuItem();
        } else if (param0 == _SRIGHT) {
            /* 右软键：退出程序 */
            mrc_exit();
        }
    }
}
```

---

## 四、图形渲染规范

### 4.1 屏幕刷新
**每次绘制完成后必须调用 `mrc_refreshScreen`**，否则画面不会更新：
```c
void drawGame(void) {
    /* 绘制背景 */
    drawBitmap(bgBitmap, 0, 0);

    /* 绘制游戏元素 */
    drawPlayer();
    drawEnemies();

    /* 绘制UI */
    drawScore();

    /* 必须刷新屏幕！ */
    mrc_refreshScreen(0, 0, SCRW, SCRH);
}
```

### 4.2 屏幕尺寸变量
使用全局变量获取屏幕尺寸，支持不同分辨率设备：
```c
extern int16 SCRW;   /* 屏幕宽度 */
extern int16 SCRH;   /* 屏幕高度 */
```

### 4.3 颜色格式
`mrc_graphics.h` 中的颜色使用 **ARGB 格式**：

```c
0xFFFF0000  /* 红色 */
0xFF00FF00  /* 绿色 */
0xFF0000FF  /* 蓝色 */
0x80000000  /* 半透明黑色 */
```

`mrc_graphics.h` 中的函数使用 **RGB 分量**：

```c
gl_drawRect(32,32,1,1,0xffff0000);      /* 红色 */
gl_clearScreen(255, 255, 255);        /* 白色 */
```

以下声明在mrc_graphics.h头文件中，这个头文件的绘制操作中color变量颜色格式为ARGB格式，例如红色为0xFFFF0000

```
#ifndef _MRC_GRAPHICS_H_
#define _MRC_GRAPHICS_H_

#include "mrc_base.h"
#include "xl_bmp.h"
enum
{
_JPG=0,
_PNG=1,
_BMP16=2
};

// 图形锚点常量
typedef enum {
    GRAPHICS_LEFT = 0,    // 左对齐
    GRAPHICS_RIGHT = 1,   // 右对齐
    GRAPHICS_TOP = 2,     // 上对齐
    GRAPHICS_BOTTOM = 3,  // 下对齐
    GRAPHICS_CENTER = 4   // 居中对齐
} GraphicsAnchor;


typedef struct
{
uint32 width; //瀹藉害
uint32 height; //楂樺害
uint32 stride;
int32 format; //鏍煎紡
uint32 flags; // 0 for now
void *ptr; //缂撳瓨
} BITMAPINFO;

// 从内存卡读取bitmap
    extern BITMAP_565 *readBitmap(char *filename);

// 从程序包中读取bitmap（通常程序包中图片放在项目assets目录下）
extern BITMAP_565 *readBitmapFromAssets(const char *filename);

// 绘制bitmap指定区域
extern int32 drawBitmapFlip(BITMAP_565 *buf, int32 x, int32 y, int32 w, int32 h, int32 sx, int32 sy);
// 绘制bitmap
/*
src: 源图像对象，即要从中提取区域的图像。
x_src: 源图像中要提取区域的左上角的x坐标。
y_src: 源图像中要提取区域的左上角的y坐标。
width: 要提取区域的宽度。
height:要提取区域的高度。
transform:变换类型
x_dest: 目标位置的x坐标，即绘制提取区域的目标位置的左上角的x坐标。
y_dest: 目标位置的y坐标，即绘制提取区域的目标位置的左上角的y坐标。
anchor: 锚点，指定目标位置的参考点。常见的锚点包括：GRAPHICS_LEFT,GRAPHICS_TOP,GRAPHICS_RIGHT,GRAPHICS_BOTTOM,GRAPHICS_CENTER
*/
extern void drawBitmapRegion(BITMAP_565 *src, int x_src, int y_src, int width, int height, int transform, int x_dest, int y_dest, int anchor);


void drawBitmap(BITMAP_565 *bmp, int32 x, int32 y);

// 扩展绘制bitmap
void drawBitmapEx(BITMAP_565 *bmp, int32 x, int32 y, int32 w, int32 h, int32 tx, int32 ty, int32 tw, int32 th);

// 释放bitmap
extern int32 bitmapFree(BITMAP_565 *b);

void gl_drawColor(uint32 color);
void gl_clearScreen(int32 r, int32 g, int32 b);
// 画矩形
void gl_drawRect(int32 x, int32 y, int32 w, int32 h, uint32 color);
void gl_drawHollowRect(int x, int y, int width, int height, uint32 color);
// 画线
void gl_drawLine(int32 x1, int32 y1, int32 x2, int32 y2, uint32 color);
// 绘制三角形
void gl_drawTriangle(int x1, int y1, int x2, int y2, int x3, int y3, uint32 color);
// 绘制空心三角形
void gl_drawHollowTriangle(int x1, int y1, int x2, int y2, int x3, int y3, uint32 color);
// 绘制多边形(填充)
void gl_drawPolygon(int *points, int count, uint32 color);
// 绘制空心多边形
void gl_drawHollowPolygon(int *points, int count, uint32 color);
// 画圆
void gl_drawCir(int32 x, int32 y, int32 r, uint32 color);
// 绘制空心圆
void gl_drawHollowCir(int x0, int y0, int r, uint32 color);
// 绘制旋转的矩形
void gl_drawRotatedRect(int16 centerX, int16 centerY, int16 width, int16 height, int32 bx, int32 by, int32 angle, uint32 color);
// 绘制旋转的空心矩形
void gl_drawRotatedHollowRect(int16 centerX, int16 centerY, int16 width, int16 height, int32 bx, int32 by, int32 angle, uint32 color);

// 画文字 font表示字体大小，可选0/1/2三种大小
int32 gl_drawText(char* pcText, int16 x, int16 y, uint8 r, uint8 g, uint8 b, int is_unicode, uint16 font);

// 获取文字宽高信息 保存到w和h中
int32 gl_textWidthHeight(char* pcText, int is_unicode, uint16 font, int32* w, int32* h);

// 获取bitmap信息
int32 bitmapGetInfo(BITMAP_565 *bmp, BITMAPINFO *info);

// 绘制emoji, size表示emoji图标的宽高
int32 emoji_draw(char *emoji, int x, int y, int size);


#endif
```









---

## 五、资源管理

### 5.1 图片资源加载
```c
/* 从资源文件加载 */
BITMAP_565* bmp = readBitmapFromAssets("fish.png");

/* 使用完毕后必须释放 */
bitmapFree(bmp);
```

### 5.2 字体绘制

```c
/* 在 mrc_init 中初始化字体 */
uc3_init();

/* 在 mrc_exitApp 中释放字体 */
uc3_free();
```

以下声明在uc3_font.h头文件中

```c
//初始化uc3字体
int32 uc3_init(void);

// 画uc3字体
int32 uc3_drawText(const char* pcText, int16 x, int16 y, uint8 r, uint8 g, uint8 b, int is_unicode);

//横屏绘制文字
int32 uc3_drawTextHor(const char *pcText, int16 x, int16 y, uint8 r, uint8 g, uint8 b, int is_unicode);

// 获取文字宽度
int uc3_getWidth(const char *pcText, int is_unicode);

// 获取文字高度
int uc3_getHeight(const char *pcText, int is_unicode);

// 释放uc3字体
void uc3_free(void);
```



### 5.3 定时器管理

```c
/* 创建和启动 */
int32 timer = mrc_timerCreate();

/*启动定时器，参数分别是 定时器、时长、传递data参数、定时器回调函数、是否循环*/
mrc_timerStart(timer, 33, 0, timer_callback, 1);

/* 退出时必须停止和删除 */
mrc_timerStop(timer);
mrc_timerDelete(timer);
```

---

## 六、按键和触摸事件

### 6.1 事件类型

// 以下定义在mrc_base.h

```
enum {
   MR_KEY_PRESS,           //按键按下事件
   MR_KEY_RELEASE,        //按键释放事件
   MR_MOUSE_DOWN,       //触摸屏（鼠标）按下事件
   MR_MOUSE_UP,            //触摸屏（鼠标）抬起/释放事件
   MR_MENU_SELECT,       //菜单选中事件
   MR_MENU_RETURN,       //菜单返回事件
   MR_DIALOG_EVENT,      // 对话框/编辑框/文本框事件
   MR_MOUSE_MOVE=12         //鼠标移动
};
```



// 以下定义在mpc.h，是mrc_base.h的简化版定义

```c
enum {
    KY_DOWN, 	 //按键按下
    KY_UP,       //按键释放
    MS_DOWN, 	 //鼠标按下
    MS_UP, 	     //鼠标释放
    MN_SLT, //菜单选择
    MN_RET, //菜单返回
    MR_DIALOG, //对话框
    MS_MOVE=12   //鼠标移动
};

```

### 6.2 按键常量

以下定义在mpc.h

```c
_UP          /* 方向键上 */
_DOWN        /* 方向键下 */
_LEFT        /* 方向键左 */
_RIGHT       /* 方向键右 */
_SELECT      /* 确认键（方向键中心） */
_SLEFT       /* 左软键 */
_SRIGHT      /* 右软键 */
_0 到 _9     /* 数字键 */
_STAR        /* * 键 */
_POUND       /* # 键 */
```

以下定义在mrc_base.h

```
enum {
    MR_KEY_0 到 MR_KEY_9,            /* 数字键 */
    MR_KEY_STAR,         //按键 *
    MR_KEY_POUND,        //按键 #
    MR_KEY_UP,           //按键 上
    MR_KEY_DOWN,         //按键 下
    MR_KEY_LEFT,         //按键 左
    MR_KEY_RIGHT,        //按键 右
    MR_KEY_POWER,        //按键 挂机键
    MR_KEY_SOFTLEFT,     //按键 左软键
    MR_KEY_SOFTRIGHT,    //按键 右软键
    MR_KEY_SEND,         //按键 接听键
    MR_KEY_SELECT       //按键 确认/选择（若方向键中间有确认键，建议设为该键）
};
```





### 6.3 事件处理模板

```c
int32 mrc_event(int32 code, int32 param0, int32 param1) {
    if (code == KY_UP) {
        /* 按键松开 */
        /* param0 是按键码 */
        if (param0 == _SELECT) {
            /* 处理确认键 */
        }
    } else if (code == MS_UP) {
        /* 触摸松开 */
        /* param0 是 X 坐标，param1 是 Y 坐标 */
        int x = param0;
        int y = param1;
        /* 处理点击 */
    }
    return 0;
}
```

---

### 
### 7.4 函数声明顺序
**函数必须在使用前声明**，否则会产生 `inventing extern` 警告：
```c
/* 前向声明 */
void drawGame(void);
void updateGame(void);

void timer_run(int32 id) {
    updateGame();  /* 正确：函数已声明 */
    drawGame();
}

void updateGame(void) {
    /* 实现 */
}

void drawGame(void) {
    /* 实现 */
}
```

---

## 八、项目结构建议

```
project/
├── main.c              # 主程序入口
├── game_menu.c         # 菜单系统
├── game_menu.h
├── assets/             # 资源文件，可以通过程序读取它们
│   ├── bg_240.png      # 背景图
│   ├── fish_01.png     # 游戏元素
│   └── logo_240.png    # Logo
├── src/                # 库文件
│   ├── mrc_base.h
│   ├── mrc_graphics.h
│   ├── uc3_font.h
│   └── mpc.h
├── 程序编写说明.md      # 平台API文档
└── 功能机开发规范.md    # 本文档
```

---

## 九、调试技巧

### 9.1 日志输出
使用 `mrc_printf` 输出调试信息：
```c
mrc_printf("Score: %d\n", score);
mrc_printf("[DEBUG] x=%d, y=%d\n", x, y);

```

注意mrc_printf和mrc_sprintf不支持%f



### 9.2 分阶段初始化

在 `mrc_init` 中打印各阶段日志，方便定位初始化问题：
```c
int32 mrc_init(void) {
    mrc_printf("[INIT] Starting...\n");

    mrc_printf("[INIT] Loading resources...\n");
    loadAssets();

    mrc_printf("[INIT] Initializing font...\n");
    uc3_init();

    mrc_printf("[INIT] Done!\n");
    return 0;
}
```

---

## 十一、参考资料

- **常用函数速查**：
  - 图形：`gl_drawRect`, `gl_drawLine`, `gl_drawCir`, `drawBitmap`
  - 文字：`uc3_drawText`, `uc3_getWidth`
  - 系统：`mrc_exit`, `mrc_printf`, `mrc_refreshScreen`
  - 定时器：`mrc_timerCreate/Start/Stop/Delete`


